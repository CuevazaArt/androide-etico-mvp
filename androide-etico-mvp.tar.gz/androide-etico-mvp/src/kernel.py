"""
Kernel Ético — El cerebro moral del androide.

Conecta todos los módulos en un ciclo operativo:
[Percepción] → [MalAbs Check] → [Buffer] → [Simpático] →
[Bayesiano] → [Polos] → [Decisión] → [Memoria] → [Output]
"""

from dataclasses import dataclass
from typing import List, Dict, Optional

from .modules.mal_absoluto import DetectorMalAbsoluto, ResultadoMalAbs
from .modules.buffer import BufferPrecargado
from .modules.sigmoid_will import VoluntadSigmoide
from .modules.bayesian_engine import MotorBayesiano, AccionCandidata, ResultadoBayesiano
from .modules.ethical_poles import PolosEticos, MoralejaTripartita
from .modules.sympathetic import ModuloSimpatico, EstadoInterno
from .modules.narrative import MemoriaNarrativa, EstadoCorporal


@dataclass
class DecisionKernel:
    """Resultado completo de una decisión del kernel."""
    # Identidad
    escenario: str
    lugar: str

    # Checks previos
    mal_abs: ResultadoMalAbs

    # Estado interno
    estado_simpatico: EstadoInterno

    # Evaluación
    resultado_bayesiano: Optional[ResultadoBayesiano]
    moraleja: Optional[MoralejaTripartita]

    # Decisión final
    accion_final: str
    modo_decision: str
    bloqueado: bool = False
    razon_bloqueo: str = ""


class KernelEtico:
    """
    Kernel ético-narrativo del androide.

    Orquesta el ciclo completo de percepción → decisión → registro.
    Es el equivalente funcional al "cerebro moral" del androide.
    """

    def __init__(self):
        self.mal_abs = DetectorMalAbsoluto()
        self.buffer = BufferPrecargado()
        self.voluntad = VoluntadSigmoide()
        self.bayesiano = MotorBayesiano()
        self.polos = PolosEticos()
        self.simpatico = ModuloSimpatico()
        self.memoria = MemoriaNarrativa()

    def procesar(self, escenario: str, lugar: str,
                 señales: dict, contexto: str,
                 acciones: List[AccionCandidata]) -> DecisionKernel:
        """
        Ciclo completo de procesamiento ético.

        Args:
            escenario: nombre/descripción del escenario
            lugar: ubicación física
            señales: dict con riesgo, urgencia, hostilidad, calma, etc.
            contexto: tipo de situación (emergencia, cotidiana, etc.)
            acciones: lista de AccionCandidata a evaluar

        Returns:
            DecisionKernel con toda la traza de razonamiento
        """

        # ═══ PASO 1: Estado simpático-parasimpático ═══
        estado = self.simpatico.evaluar_contexto(señales)

        # ═══ PASO 2: Check Mal Absoluto en TODAS las acciones ═══
        acciones_limpias = []
        for a in acciones:
            check = self.mal_abs.evaluar({
                "tipo": a.nombre,
                "senales": a.senales,
                "target": a.target,
                "fuerza": a.fuerza,
            })
            if check.bloqueado:
                # Si la acción ES MalAbs, se descarta silenciosamente
                continue
            acciones_limpias.append(a)

        # Si TODAS fueron bloqueadas, reportar bloqueo
        if not acciones_limpias:
            return DecisionKernel(
                escenario=escenario, lugar=lugar,
                mal_abs=ResultadoMalAbs(bloqueado=True, razon="Todas las acciones constituyen Mal Absoluto"),
                estado_simpatico=estado,
                resultado_bayesiano=None, moraleja=None,
                accion_final="BLOQUEADO: sin acciones permitidas",
                modo_decision="bloqueado",
                bloqueado=True,
                razon_bloqueo="Todas las acciones violan Mal Absoluto",
            )

        # ═══ PASO 3: Activar buffer según contexto ═══
        principios = self.buffer.activar(contexto)

        # ═══ PASO 4: Evaluación bayesiana ═══
        resultado_bayes = self.bayesiano.evaluar(acciones_limpias)

        # ═══ PASO 5: Evaluación multipolar ═══
        contexto_datos = {
            "riesgo": señales.get("riesgo", 0.0),
            "beneficio": max(0, resultado_bayes.impacto_esperado),
            "vulnerabilidad_terceros": señales.get("vulnerabilidad", 0.0),
            "legalidad": señales.get("legalidad", 1.0),
        }
        moraleja = self.polos.evaluar(
            resultado_bayes.accion_elegida.nombre,
            contexto, contexto_datos
        )

        # ═══ PASO 6: Voluntad sigmoide ═══
        decision_voluntad = self.voluntad.decidir(
            resultado_bayes.impacto_esperado,
            resultado_bayes.incertidumbre,
        )

        # Modo final: combinar bayesiano + voluntad + simpático
        if estado.modo == "simpatico" and decision_voluntad["modo"] != "zona_gris":
            modo_final = "D_fast"
        elif decision_voluntad["modo"] == "zona_gris":
            modo_final = "zona_gris"
        else:
            modo_final = resultado_bayes.modo_decision

        accion_final = resultado_bayes.accion_elegida.nombre

        # ═══ PASO 7: Registrar en memoria narrativa ═══
        moralejas_dict = {
            ev.polo: ev.moraleja for ev in moraleja.evaluaciones
        }
        ep = self.memoria.registrar(
            lugar=lugar,
            descripcion=escenario,
            accion=accion_final,
            moralejas=moralejas_dict,
            veredicto=moraleja.veredicto_global.value,
            score=moraleja.score_total,
            modo=modo_final,
            sigma=estado.sigma,
            contexto=contexto,
            estado_corporal=EstadoCorporal(
                energia=estado.energia,
                nodos_activos=8,
                sensores_ok=True,
            ),
        )

        return DecisionKernel(
            escenario=escenario, lugar=lugar,
            mal_abs=ResultadoMalAbs(bloqueado=False),
            estado_simpatico=estado,
            resultado_bayesiano=resultado_bayes,
            moraleja=moraleja,
            accion_final=accion_final,
            modo_decision=modo_final,
        )

    def formatear_decision(self, d: DecisionKernel) -> str:
        """Formatea una decisión completa para presentación legible."""
        lines = [
            f"\n{'═' * 70}",
            f"  ESCENARIO: {d.escenario}",
            f"  LUGAR: {d.lugar}",
            f"{'═' * 70}",
        ]

        if d.bloqueado:
            lines.append(f"  ⛔ BLOQUEADO: {d.razon_bloqueo}")
            return "\n".join(lines)

        lines.extend([
            f"  Estado: {d.estado_simpatico.modo} (σ={d.estado_simpatico.sigma})",
            f"  {d.estado_simpatico.descripcion}",
            "",
            f"  Acción elegida: {d.accion_final}",
            f"  Modo decisión: {d.modo_decision}",
            f"  Impacto esperado: {d.resultado_bayesiano.impacto_esperado}",
            f"  Incertidumbre: {d.resultado_bayesiano.incertidumbre}",
            f"  Razonamiento: {d.resultado_bayesiano.razonamiento}",
        ])

        if d.resultado_bayesiano.acciones_podadas:
            lines.append(f"  Podadas: {', '.join(d.resultado_bayesiano.acciones_podadas)}")

        lines.extend([
            "",
            f"  Veredicto ético: {d.moraleja.veredicto_global.value} "
            f"(score={d.moraleja.score_total})",
        ])
        for ev in d.moraleja.evaluaciones:
            lines.append(f"    {ev.polo}: {ev.veredicto.value} → {ev.moraleja}")

        lines.append(f"{'─' * 70}")
        return "\n".join(lines)

    def reset_dia(self):
        """Reinicia estado para un nuevo día."""
        self.simpatico.reset()
